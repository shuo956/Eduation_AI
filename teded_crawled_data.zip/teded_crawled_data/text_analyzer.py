import json




class text_analysis:
    def __init__(self):
        self.relation=None


    def read_realtion(self,path):
        relation=open(path)
        relation=json.load(relation)
        self.relation=relation
    def read_videoinfo(self,path):
        video_info=open(path)
        video_info=





def main():

    analysis=text_analysis()
    analysis.read_realtion('/home/shuo/Documents/AI_learning/LearningQ/data/teded/teded_crawled_data/category_video_relation')
    print(analysis.relation)


if __name__=='__main__':
    main()